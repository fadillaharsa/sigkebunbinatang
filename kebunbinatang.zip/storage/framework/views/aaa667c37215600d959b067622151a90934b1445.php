

<?php $__env->startSection('title'); ?>
    <title><?php echo e($berita->title); ?> - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div >
    <div class="d-flex justify-content-between align-items-center mb-3 text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-3"><b><?php echo e($berita->title); ?></b></H1>
        <span></span>
    </div>
    <img src="<?php echo e(asset('storage/'.$berita->image)); ?>" class="img-fluid mb-3" style="width: 100%">
    <p class="text-info"><?php echo e($berita->user->name); ?> | <?php echo e(date('d M Y', strtotime($berita->created_at))); ?></p>
    <p><?php echo $berita->content; ?></p>
   
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/berita/detail.blade.php ENDPATH**/ ?>