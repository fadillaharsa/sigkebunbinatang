

<?php $__env->startPush('scriptTop'); ?>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <H1 class="mb-4"><b>EDIT BERITA</b></H1>
            <a href="<?php echo e(route('news.index')); ?>" class="btn btn-success text-white"><i class="fas fa-angle-left"></i> Kembali</a>
            
            <div class="mt-4">

                <?php echo Form::model($news,['route'=>['news.update',$news->id], 'method'=>'put', 'files'=>true]); ?>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Judul Berita</label>
                                <?php echo Form::text('title',null,['class'=>$errors->has('title') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Gambar</label>
                                <br><?php echo e($news->image); ?>

                                <button class="btn btn-sm btn-success" type="button" data-toggle="collapse" data-target="#collapseIcon" aria-expanded="false" aria-controls="collapseIcon">
                                    <i class="fas fa-exchange-alt"></i> Ganti Gambar
                                </button>
                                <div class="collapse" id="collapseIcon">
                                  <div class="card card-body">
                                    <div class="input-group">
                                        <input type="file" name="image" class="form-control">
                                    </div>
                                  </div>
                                </div>
                            </div>
                            <?php if($errors->has('image')): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Konten Berita</label>
                                <?php echo Form::textarea('content',null,[
                                    'class'=>$errors->has('content') ? 'form-control is-invalid' : 'form-control',
                                    'id'=>'summernote',
                                ]); ?>

                            </div>
                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-12">
                        <button type="submit" class="btn btn-success">Simpan</button>
                        </div>
                    </div>
                <?php echo Form::close(); ?>


            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
    <script type="text/javascript">
        $('#summernote').summernote({
            height: 400
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>