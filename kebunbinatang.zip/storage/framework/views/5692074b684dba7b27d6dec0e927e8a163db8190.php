<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <a href="<?php echo e(route('facility.index')); ?>" class="text-dark"><img src="<?php echo e(asset('assets/images/dashboard1.png')); ?>" class="img-fluid mb-1">
            <p>Fasilitas dan Kandang</p></a>
        </div>
        <div class="col-sm-4">
            <a href="<?php echo e(route('animal.index')); ?>" class="text-dark"><img src="<?php echo e(asset('assets/images/dashboard2.png')); ?>" class="img-fluid mb-1">
            <p>Satwa</p></a>
        </div>
        <div class="col-sm-4">
            <a href="<?php echo e(route('route.index')); ?>" class="text-dark"><img src="<?php echo e(asset('assets/images/dashboard3.png')); ?>" class="img-fluid mb-1">
            <p>Rute</p></a>
        </div>
        <div class="col-sm-4">
            <a href="<?php echo e(route('review.index')); ?>" class="text-dark"><img src="<?php echo e(asset('assets/images/dashboard4.png')); ?>" class="img-fluid mb-1">
            <p>Ulasan</p></a>
        </div>
        <div class="col-sm-4">
            <a href="<?php echo e(route('news.index')); ?>" class="text-dark"><img src="<?php echo e(asset('assets/images/dashboard5.png')); ?>" class="img-fluid mb-1">
            <p>Berita</p></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>