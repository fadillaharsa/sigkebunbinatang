

<?php $__env->startSection('title'); ?>
    <title><?php echo e($wahana->facility->title); ?> - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div >
    <div class="d-flex justify-content-between align-items-center text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-3"><b><?php echo e($wahana->facility->title); ?></b></H1>
        <span></span>
    </div>
    <p class=" text-center <?php if($wahana->category=='Tunggangan'): ?> text-primary <?php endif; ?> <?php if($wahana->category=='Foto Bersama Satwa'): ?> text-info <?php endif; ?> <?php if($wahana->category=='Feeding'): ?> text-danger <?php endif; ?>"><?php echo e($wahana->category); ?></p>
    <img src="<?php echo e(asset('storage/'.$wahana->facility->photo)); ?>" class="img-fluid mb-3" style="width: 100%">    
    <a href="#" onclick="openDirectionPage(<?php echo e($wahana->facility->latitude); ?>, <?php echo e($wahana->facility->longitude); ?>, <?php echo e($wahana->facility->id); ?>)" class="mb-3 btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
        <span></span>
        <span class="ml-2">Petunjuk Jalan</span>
        <i class="fas fa-route"></i>
    </a>
    <p><?php echo $wahana->description; ?></p>
    <p><b>Harga: <?php if($wahana->price=='0'): ?> Seikhlasnya <?php else: ?> Rp<?php echo e($wahana->price); ?> <?php endif; ?></b></p>
   
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    window.hereApiKey = "<?php echo e(env('HERE_API_KEY')); ?>"
</script>
<script src="<?php echo e(asset('js/here.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/wahana/detail.blade.php ENDPATH**/ ?>