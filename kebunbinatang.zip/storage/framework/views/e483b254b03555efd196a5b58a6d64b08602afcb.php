

<?php $__env->startSection('title'); ?>
    <title>Rute - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-5"><b>RUTE PERJALANAN</b></H1>
        <span></span>
    </div>
    <p>Fitur ini dapat membantu Anda melakukan tour perjalanan mengelilingi Kebun Binatang Bandung.</p>
</div>

<?php $__currentLoopData = $rute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="#" <?php if($routelist->count()==$rute->count()): ?> onclick="openDirection(<?php echo e($routelist[$loop->index]->facility->latitude); ?>, <?php echo e($routelist[$loop->index]->facility->longitude); ?>, <?php echo e($rute->id); ?>,1)" <?php endif; ?> class="card mb-2" style="color:black">
    <div class="card-body row">
        <div class="col-10">
            <h2><b><?php echo e($rute->name); ?></b></h2>
            <p class="mb-1"><?php echo e($rute->description); ?>

            </p>
            <p class="mb-0 text-info">Estimasi waktu: <?php echo e($rute->duration); ?>

            </p>
        </div>
        <div class="col-2 d-flex justify-content-between align-items-center">
            <i class="fas fa-chevron-right"></i>
        </div>
    </div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<a href="https://www.instagram.com/bandung_zoological/" target="_blank" class="card mb-2" style="color:black">
    <div class="card-body row">
        <div class="col-10">
            <h2><b>Jasa Tour Guide</b></h2>
            <p class="mb-1">Kami menyediakan Zoo Educator (Pemandu) sesuai permintaan dan terbatas.
            </p>
            <p class="mb-0 text-info">Silakan hubungi kami
            </p>
        </div>
        <div class="col-2 d-flex justify-content-between align-items-center">
            <i class="fas fa-chevron-right"></i>
        </div>
    </div>
</a>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    window.hereApiKey = "<?php echo e(env('HERE_API_KEY')); ?>"
</script>
<script src="<?php echo e(asset('js/here.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/rute/index.blade.php ENDPATH**/ ?>