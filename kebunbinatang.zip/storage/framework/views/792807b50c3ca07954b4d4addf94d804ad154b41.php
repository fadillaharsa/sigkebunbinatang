

<?php $__env->startSection('title'); ?>
    <title>Berita - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scriptTop'); ?>
<style>
    .card {
        flex-direction: row;
        align-items: center;
    }
    .card-title {
        font-weight: bold;
    }
    .card img {
        width: 30%;
        border-top-right-radius: 0;
        border-bottom-left-radius: calc(0.25rem - 1px);
        object-fit: cover;
        height:150px
    }

    @media  only screen and (max-width: 768px) {
        a {
            display: none;
        }
        .card-body {
            padding: 0.5em 1.2em;
        }
        .card-body .card-text {
            margin: 0;
        }
        .card img {
            width: 20%;
            object-fit: cover
        }
    }
    @media  only screen and (max-width: 1200px) {
        .card img {
            width: 30%;
            object-fit: cover;
            height:100px
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div >
    <div class="d-flex justify-content-between align-items-center mb-3 text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-3"><b>BERITA</b></H1>
        <span></span>
    </div>
    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beritakbb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('lihatberita',$beritakbb->id)); ?>" class="card mb-2" style="color:black">
        <img src="<?php echo e(asset('storage/'.$beritakbb->image)); ?>" />
        <div class="card-body">
        <h3 class="card-title"><?php echo e($beritakbb->title); ?></h3>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row justify-content-center">
        <?php echo e($berita->links()); ?>

    </div>
   
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/berita/index.blade.php ENDPATH**/ ?>