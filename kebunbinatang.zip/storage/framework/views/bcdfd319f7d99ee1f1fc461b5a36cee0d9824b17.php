

<?php $__env->startSection('title'); ?>
    <title>Pengelolaan Fasilitas dan Kandang - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <H1 class="mb-4"><b>PENGELOLAAN LIST RUTE <?php echo e($route->id); ?></b></H1>
            <a href="<?php echo e(route('createlist',$route->id)); ?>" class="btn btn-success text-white"><i class="fas fa-plus-circle"></i> Tambah</a>
            <?php if(session('status')): ?>
                <div class="alert alert-success mt-4" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="mt-4">
                <table id="table-data" class="table table-striped table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Urutan Rute</th>
                            <th>Nama Fasilitas</th>
                            <th>Kelola</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Urutan Rute</th>
                            <th>Nama Fasilitas</th>
                            <th>Kelola</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $routelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($list->order); ?></td>
                                <td><?php echo e($list->facility->title); ?></td>
                                <td>
                                    <a href="<?php echo e(route('routelist.edit',$route->id)); ?>" class="btn btn-sm btn-info text-white"><i class="fas fa-edit"></i> Edit</a>
                                    <?php if($list->order == $routelist->count()): ?>
                                    <a href="" class="btn btn-sm btn-danger text-white addAttr" data-id=<?php echo e($list->id); ?> data-idrute=<?php echo e($route->id); ?> data-toggle="modal" data-target="#deleteModal">
                                        <i class="fas fa-trash"></i> Hapus
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
            <form action="<?php echo e(route('routelist.destroy', 'id')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="hidden" id="id" name="id" value="">
            <input type="hidden" id="idrute" name="idrute" value="">
                <div class="modal-body">
                    Apakah anda yakin akan menghapus data list rute?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $('.addAttr').click(function() {
    var id = $(this).data('id');
    $('#id').val(id);
    var idrute = $(this).data('idrute');
    $('#idrute').val(idrute);
    } );
</script>
<script>
    $(document).ready(function(){
        $('#table-data').DataTable();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/admin/routelist/index.blade.php ENDPATH**/ ?>