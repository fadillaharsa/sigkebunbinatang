<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="d-flex justify-content-between mb-3">
            <div id="create-facility">
                <a href="<?php echo e(route('facility.create')); ?>" class="btn btn-primary">Pin!</a>
            </div>
            <div id="view-facility">
                <a href="<?php echo e(route ('facility.index')); ?>" class="btn btn-secondary"><i class="fas fa-list"></i></a> |
                <a href="#" class="btn btn-secondary"><i class="fas fa-globe"></i></a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/components/facility.blade.php ENDPATH**/ ?>