

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <H1 class="mb-4"><b>TAMBAH SATWA</b></H1>
            <a href="<?php echo e(route('animal.index')); ?>" class="btn btn-success text-white"><i class="fas fa-angle-left"></i> Kembali</a>
            
            <?php if(empty($select)): ?>
                <div class="alert alert-success mt-4" role="alert">
                    Maaf belum bisa
                </div>
            <?php endif; ?>
            <div class="mt-4">

                <?php echo Form::open(['route'=>'animal.store', 'method'=>'post', 'files'=>true]); ?>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Nama Satwa</label>
                                <?php echo Form::text('name',null,['class'=>$errors->has('name') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Nama Latin</label>
                                <?php echo Form::text('latin',null,['class'=>$errors->has('latin') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                            <?php $__errorArgs = ['latin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Lokasi Fasilitas</label>
                                <?php echo Form::select('facility_id', $select, null, ['class'=>'form-control','placeholder' => 'Pilih lokasi fasilitas']); ?>

                            </div>
                            <?php if($errors->has('facility_id')): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->get('facility_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Deskripsi</label>
                                <?php echo Form::textarea('description',null,[
                                    'class'=>$errors->has('description') ? 'form-control is-invalid' : 'form-control',
                                    'cols'=>"10",
                                    'rows'=>"3"
                                ]); ?>

                            </div>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group increment">
                                <label for="">Foto</label>
                                <div class="input-group">
                                    <input type="file" name="photo[]" class="form-control">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-outline-primary btn-add"><i class="fas fa-plus-square"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php if($errors->has('photo')): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->get('photo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <div class="clone invisible">
                                <div class="input-group mt-2">
                                    <input type="file" name="photo[]" class="form-control">
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-outline-danger btn-remove"><i class="fas fa-minus-square"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </div>
                <?php echo Form::close(); ?>


            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        window.action = "submit"
        jQuery(document).ready(function () {
            jQuery(".btn-add").click(function () {
                let markup = jQuery(".invisible").html();
                jQuery(".increment").append(markup);
            });
            jQuery("body").on("click", ".btn-remove", function () {
                jQuery(this).parents(".input-group").remove();
            })
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/admin/animal/create.blade.php ENDPATH**/ ?>