

<?php $__env->startSection('title'); ?>
    <title><?php echo e($fasilitas->title); ?> - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scriptTop'); ?>
<style>
    .card {
        flex-direction: row;
        align-items: center;
    }
    .card-title {
        font-weight: bold;
    }
    .card img {
        width: 30%;
        border-top-right-radius: 0;
        border-bottom-left-radius: calc(0.25rem - 1px);
        object-fit: cover;
        height:150px
    }

    @media  only screen and (max-width: 768px) {
        a {
            display: none;
        }
        .card-body {
            padding: 0.5em 1.2em;
        }
        .card-body .card-text {
            margin: 0;
        }
        .card img {
            width: 20%;
            object-fit: cover;
        }
    }
    @media  only screen and (max-width: 1200px) {
        .card img {
            width: 30%;
            object-fit: cover;
            height:100px
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div >
    <div class="d-flex justify-content-between align-items-center mb-3 text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-3"><b><?php echo e(strtoupper($fasilitas->title)); ?></b></H1>
        <span></span>
    </div>
    <img src="<?php echo e(asset('storage/'.$fasilitas->photo)); ?>" class="img-fluid mb-3" style="width: 100%">
    <a href="#" onclick="openDirectionPage(<?php echo e($fasilitas->latitude); ?>, <?php echo e($fasilitas->longitude); ?>, <?php echo e($fasilitas->id); ?>)" class="mb-3 btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
        <span></span>
        <span class="ml-2">Petunjuk Jalan</span>
        <i class="fas fa-route"></i>
    </a>
    <p><?php echo e($fasilitas->description); ?></p>
    <H1 class="mt-4"><b>SATWA</b></H1>
    <?php if($fasilitas->animal=='[]'): ?>
    <p>Tidak ada satwa di fasilitas ini.</p>
        <?php else: ?>
        <?php $__currentLoopData = $fasilitas->animal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satwa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('lihatsatwa',$satwa->id)); ?>" class="card mb-2" style="color:black">
            <img src="<?php echo e(asset('storage/'.$satwa->photos[0]->path)); ?>" class="card-img-top" />
            <div class="card-body row">
                <div class="col-10">
                    <h2 class="mt-1"><b><?php echo e($satwa->name); ?></b></h2>
                    <p class="mb-0"><?php echo e($satwa->latin); ?></p>
                </div>
                <div class="col-2 d-flex justify-content-between align-items-center">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
    <?php endif; ?>
    <H1 class="mt-4"><b>ULASAN</b></H1>
    <?php if($ulasan=='[]'): ?>
        <p>Belum ada ulasan untuk fasilitas ini.</p>
    <?php else: ?>
        <?php for($i = 0; $i < 4; $i++): ?>
            <i class="fas fa-star text-warning" style="font-size: 30px"></i>
        <?php endfor; ?> 
        <ul class="mt-2 pl-3">
        <?php $__currentLoopData = $ulasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><i>"<?php echo e($ulasan->review); ?>"</i></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <a href="<?php echo e(route('ulasan',$fasilitas->id)); ?>" class="mb-3 btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
        <span></span>
        <span class="ml-2">Beri Ulasan</span>
        <i class="fas fa-chevron-right"></i>
    </a>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    window.hereApiKey = "<?php echo e(env('HERE_API_KEY')); ?>"
</script>
<script src="<?php echo e(asset('js/here.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/peta/detail.blade.php ENDPATH**/ ?>