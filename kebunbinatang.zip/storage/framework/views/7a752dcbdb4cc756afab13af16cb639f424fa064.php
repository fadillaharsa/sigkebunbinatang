

<?php $__env->startSection('title'); ?>
    <title>Tentang - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center">
    <div class="d-flex justify-content-between align-items-center text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-2"><b>PETUNJUK JALAN</b></H1>
        <span></span>
    </div>
    <p>Menuju <?php echo e($fasilitas->title); ?></p>
    <div style="height:340px" class="mb-3" id="mapContainer"></div>  
    <a href="<?php echo e(route('lihatfasilitas',$fasilitas->id)); ?>" class="mb-3 btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
        <span></span>
        <span class="ml-2">Lihat Informasi Fasilitas</span>
        <i class="fas fa-chevron-right"></i>
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        window.action = "direction"
        window.facilityIcon = "<?php echo e($fasilitas->icon); ?>"
        window.hereApiKey = "<?php echo e(env('HERE_API_KEY')); ?>"
    </script>
    <script src="<?php echo e(asset('js/here.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/peta/direction.blade.php ENDPATH**/ ?>