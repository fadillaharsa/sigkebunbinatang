

<?php $__env->startSection('title'); ?>
    <title>Tentang - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-bottom:80px">
    <div class="d-flex justify-content-between align-items-center text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-2"><b><?php echo e($destinasi->order); ?> DARI <?php echo e($jumlah); ?> FASILITAS TELAH DIKUNJUNGI</b></H1>
        <span></span>
    </div>
    <p class="text-center">Sekarang Anda harus berada di:<br><b><?php echo e($destinasi->facility->title); ?></b></p>
    <img src="<?php echo e(asset('storage/'.$destinasi->facility->photo)); ?>" class="img-fluid mb-3" style="width: 100%">
    <p><?php echo e($destinasi->facility->description); ?></p>
    <H1 class="mb-3"><b>PETA</b></H1>
    <div style="height:500px" id="mapContainer"></div>  
    
    <div style="margin-bottom:90px" class="px-3 fixed-bottom">
        <a <?php if($destinasi->order<$jumlah): ?> onclick="openDirection(<?php echo e($routelist->facility->latitude); ?>, <?php echo e($routelist->facility->longitude); ?>, <?php echo e($routelist->route_id); ?>, <?php echo e($routelist->order); ?>)" <?php else: ?> href=<?php echo e(route('ruteselesai')); ?> <?php endif; ?> class="btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
            <span></span>
            <span class="ml-2"><?php if($destinasi->order<$jumlah): ?> Lanjutkan Perjalanan <?php else: ?> Perjalanan Selesai <?php endif; ?></span>
            <i class="fas fa-chevron-right"></i>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        window.action = "direction"
    </script>
    <script>
        window.hereApiKey = "<?php echo e(env('HERE_API_KEY')); ?>"
    </script>
    <script src="<?php echo e(asset('js/here.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/rute/detail.blade.php ENDPATH**/ ?>