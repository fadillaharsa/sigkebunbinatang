

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row justify-content-center">
        <div class="col-md-12">
            <H1 class="mb-4"><b>TAMBAH FASILITAS ATAU KANDANG SATWA</b></H1>
            <a href="<?php echo e(route('facility.index')); ?>" class="btn btn-success text-white"><i class="fas fa-angle-left"></i> Kembali</a>
            
            <div class="mt-4">

                <?php echo Form::open(['route'=>'facility.store', 'method'=>'post', 'files'=>true]); ?>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Nama Fasilitas</label>
                                <?php echo Form::text('title',null,['class'=>$errors->has('title') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Kode Fasilitas</label>
                                <?php echo Form::text('code',null,['class'=>$errors->has('code') ? 'form-control is-invalid' : 'form-control']); ?>

                            </div>
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Kategori Fasilitas</label>
                                <?php echo e(Form::select('category', ['Kandang Satwa' => 'Kandang Satwa', 'Fasilitas Isoma' => 'Fasilitas Isoma', 'Fasilitas Bermain' => 'Fasilitas Bermain','Toilet' => 'Toilet','Gerbang' => 'Gerbang'], null, ['class'=>'form-control','placeholder' => 'Pilih kategori fasilitas'])); ?>

                            </div>
                            <?php if($errors->has('category')): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->get('category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Deskripsi</label>
                                <?php echo Form::textarea('description',null,[
                                    'class'=>$errors->has('description') ? 'form-control is-invalid' : 'form-control',
                                    'cols'=>"10",
                                    'rows'=>"3"
                                ]); ?>

                            </div>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Photo</label>
                                <div class="input-group">
                                    <input type="file" name="photo" class="form-control">
                                </div>
                            </div>
                            <?php if($errors->has('photo')): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->get('photo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Icon</label>
                                <div class="input-group">
                                    <input type="file" name="icon" class="form-control">
                                </div>
                            </div>
                            <?php if($errors->has('icon')): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->get('icon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($error); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-12">
                            <div id="here-maps" class="mb-3">
                                <label for="">Pin Lokasi</label>
                                <div style="height:500px" id="mapContainer"></div>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Latitude</label>
                                <?php echo Form::text('latitude',null,['class'=>$errors->has('latitude') ? 'form-control is-invalid' : 'form-control', 'id' => 'lat']); ?>

                            </div>
                            <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="">Longitude</label>
                                <?php echo Form::text('longitude',null,['class'=>$errors->has('longitude') ? 'form-control is-invalid' : 'form-control', 'id' => 'lng']); ?>

                            </div>
                            <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-sm-12">
                            <div class="alert alert-danger mb-3" role="alert">
                                <input type="checkbox" name="isFeed" id="mycheckbox" value="1" /> Ceklist Di Sini dan Isi Data Di Bawah Apabila Termasuk Fasilitas Feeding, Tunggangan, atau Foto Bersama Satwa.
                            </div>
                            
                            <div id="mycheckboxdiv" style="display:none" class="card card-body alert-danger mb-4">
                                <div class="row">
                                    <div class="col-sm-12 mb-3">
                                        <h1><b>INFORMASI WAHANA: FEEDING, TUNGGANGAN, ATAU FOTO SATWA</b></h1>
                                        Keterangan: Tidak perlu isi bagian merah ini jika tidak termasuk fasilitas feeding, tunggangan, atau foto satwa.
                                    </div>

                                    <div class="col-sm-6 mb-3">
                                        <div class="form-group">
                                            <label for="">Kategori Wahana</label>
                                            <?php echo e(Form::select('categoryFeed', ['Feeding' => 'Feeding', 'Tunggangan' => 'Tunggangan', 'Foto Bersama Satwa' => 'Foto Bersama Satwa'], null, ['class'=>'form-control','placeholder' => 'Pilih kategori wahana'])); ?>

                                        </div>
                                        <?php if($errors->has('categoryFeed')): ?>
                                            <ul class="alert alert-danger">
                                                <?php $__currentLoopData = $errors->get('categoryFeed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span><?php echo e($error); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-6 mb-3">
                                        <div class="form-group">
                                            <label for="">Harga Wahana</label>
                                            <?php echo Form::number('price',null,['class'=>$errors->has('price') ? 'form-control is-invalid' : 'form-control']); ?>

                                        </div>
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="">Deskripsi Wahana</label>
                                            <?php echo Form::textarea('descriptionFeed',null,[
                                                'class'=>$errors->has('descriptionFeed') ? 'form-control is-invalid' : 'form-control',
                                                'cols'=>"10",
                                                'rows'=>"3"
                                            ]); ?>

                                        </div>
                                        <?php $__errorArgs = ['descriptionFeed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                               
                            </div>
                        </div>

                        <div class="col-sm-12">
                        <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </div>
                <?php echo Form::close(); ?>


            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        window.action = "submit"
    </script>
    <script type="text/javascript">
        document.getElementById('mycheckbox').addEventListener('change', function () {
            var style = this.value == 1 ? 'block' : 'none';
            document.getElementById('mycheckboxdiv').style.display = style;
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/admin/facility/create.blade.php ENDPATH**/ ?>