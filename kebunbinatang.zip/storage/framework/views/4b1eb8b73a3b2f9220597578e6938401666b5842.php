<?php $__env->startSection('content'); ?>

<div class="text-center pt-4">
    <span style="font-size: 120px">!</span><br>
    <h1><b>KONEKSI TERPUTUS</b></h1>
    <h2>Anda tidak terhubung ke internet. Pastikan perangkat Anda telah terkoneksi internet dengan baik.</h2>
    <button class="mt-3 btn btn-success text-white" onClick="window.location.reload();">Refresh Halaman</button>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>