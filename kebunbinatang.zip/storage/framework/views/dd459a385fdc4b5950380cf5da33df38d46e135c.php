

<?php $__env->startSection('title'); ?>
    <title>Ulasan - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scriptTop'); ?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css">
<style>  
    .starrating > input {display: none;}  /* Remove radio buttons */
    .starrating > label:before { 
        content: "\f005"; /* Star */
        margin-right: 5px;
        font-size: 2em;
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        display: inline-block; 
        }
    .starrating > label {
        color: #222222;
    }
    .starrating > input:checked ~ label {
        color: #ffca08 ; }
    .starrating > input:hover ~ label {
        color: #ffca08 ;  }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div >
    <div class="d-flex justify-content-between align-items-center text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-3"><b>ULASAN FASILITAS/KANDANG</b></H1>
        <span></span>
    </div>
    <p class="mt-0 text-center">Fasilitas: <?php echo e($fasilitas->title); ?></p>
    <div class="mt-4">
        <?php echo Form::open(['route'=>['ulasan', $fasilitas->id], 'method'=>'post', 'files'=>true]); ?>

            <div class="row">

                <input type="hidden" name="facility_id" value="<?php echo e($fasilitas->id); ?>">

                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="">Nama</label>
                        <?php echo Form::text('name',null,['class'=>$errors->has('name') ? 'form-control is-invalid' : 'form-control']); ?>

                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="">Ulasan</label>
                        <?php echo Form::textarea('review',null,[
                            'class'=>$errors->has('review') ? 'form-control is-invalid' : 'form-control',
                            'cols'=>"10",
                            'rows'=>"3",
                            'placeholder'=>'Tulis ulasanmu di sini.'
                        ]); ?>

                    </div>
                    <?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-12">
                    <label for="">Rating</label>
                </div>
                <div class="starrating d-flex flex-row-reverse ml-3">
                    <input type="radio" id="star5" name="rating" value="5" checked <?php echo e(old('rating') == "5" ? "checked": ""); ?> required><label for="star5" title="5 Bintang"></label>
                    <input type="radio" id="star4" name="rating" value="4" <?php echo e(old('rating') == "4" ? "checked": ""); ?> required><label for="star4" title="4 Bintang"></label>
                    <input type="radio" id="star3" name="rating" value="3" <?php echo e(old('rating') == "3" ? "checked": ""); ?> required><label for="star3" title="3 Bintang"></label>
                    <input type="radio" id="star2" name="rating" value="2" <?php echo e(old('rating') == "2" ? "checked": ""); ?> required><label for="star2" title="2 Bintang"></label>
                    <input type="radio" id="star1" name="rating" value="1" <?php echo e(old('rating') == "1" ? "checked": ""); ?> required><label for="star1" title="1 Bintang"></label>
                </div>
                <?php if($errors->has('rating')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('rating')); ?>

                    </div>
                <?php endif; ?> 
                
                <div class="col-sm-12 mt-3">
                    <button type="submit" class="mb-3 btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
                        <span></span>
                        <span class="ml-2">Kirim Ulasan</span>
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        <?php echo Form::close(); ?>

    </div>
   
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/peta/review.blade.php ENDPATH**/ ?>