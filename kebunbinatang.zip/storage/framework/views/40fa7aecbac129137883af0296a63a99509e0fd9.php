

<?php $__env->startSection('title'); ?>
    <title><?php echo e($satwa->name); ?> - SIG Kebun Binatang Bandung</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center text-center">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-success text-white rounded-circle">
            <i class="fas fa-arrow-left"></i>
        </a>
        <H1 class="mr-3"><b><?php echo e($satwa->name); ?></b></H1>
        <span></span>
    </div>
    <p class="text-center"><?php echo e($satwa->latin); ?></p>
    <div id="carouselAnimal" class="carousel slide mb-3" data-ride="carousel">
        <div class="carousel-inner">
        <?php $__currentLoopData = $satwa->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($key==0 ? 'active' : ''); ?>">
                <img class="d-block w-100" src="<?php echo e(asset('storage/'.$foto->path)); ?>" alt="First slide">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carouselAnimal" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselAnimal" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <a href="" class="mb-3 btn btn-success text-white btn-block d-flex justify-content-between align-items-center">
        <span></span>
        <span class="ml-2">Petunjuk Jalan</span>
        <i class="fas fa-route"></i>
    </a>
    <p><?php echo e($satwa->description); ?></p>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kebunbinatang\resources\views/app/peta/animal.blade.php ENDPATH**/ ?>